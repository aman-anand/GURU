var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/354b3e8b3d2379621200e26eb4b1511d.svg",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/d4cbb847ebf68369bbe07d502d784812.png",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/runtime.42156209062411e807de.js",
      "/"
    ],
    "additional": [
      "/npm.material-ui.030c26b72836fd1bf24d.chunk.js",
      "/1.b8d5b51f34f8c7d44f1e.chunk.js",
      "/2.4cc7a1436af6846aa4eb.chunk.js",
      "/npm.css-loader.aaa01576ab27b146df4e.chunk.js",
      "/npm.intl.c5cd2291db52939a7222.chunk.js",
      "/5.c9fbbd1b6d4f2136d7f5.chunk.js",
      "/6.f0a08d6c5a1f699fe1f4.chunk.js",
      "/7.ce453b20d3eb23e49f4f.chunk.js",
      "/main.b759765e5d489a228b99.chunk.js",
      "/npm.axios.e0f7838f693ab463425d.chunk.js",
      "/npm.babel.9f357335c0a55c905a97.chunk.js",
      "/npm.enquire.js.6c5716666d080501c1c0.chunk.js",
      "/npm.lodash.5b3072d46033a9d8e7e3.chunk.js",
      "/npm.react-app-polyfill.7ba3d8970fa918f815bb.chunk.js",
      "/npm.react-redux.c70dd14a0546014869b9.chunk.js",
      "/npm.react-slick.b19dea34bd64274dd0a8.chunk.js",
      "/npm.react-swipeable-views.0690c0d6469a1eb9938f.chunk.js",
      "/npm.react-swipeable-views-core.496e0a9bd69f05022390.chunk.js",
      "/npm.react-transition-group.909e5e254ff61fca54af.chunk.js",
      "/npm.slick-carousel.fd402ec6e7c2423d203d.chunk.js",
      "/npm.video-react.aedd4582b562fa501bbd.chunk.js",
      "/npm.warning.590e4a3c9c5315441224.chunk.js",
      "/23.58660d647c6cef9a9de7.chunk.js",
      "/24.318006029f1e04913f4f.chunk.js",
      "/25.4f3ffb7c59be418067b8.chunk.js",
      "/26.4708c482952b6da645a9.chunk.js",
      "/27.8e8050abafbb1403489d.chunk.js",
      "/28.b68de3571cc541ceaf6a.chunk.js",
      "/29.9c5f755b3c413d52c2c2.chunk.js",
      "/30.92fea79277f277f10700.chunk.js",
      "/31.aefc299677a23137dcc8.chunk.js",
      "/32.7d38040cf7f533b8fb35.chunk.js",
      "/33.cdd4659274b06a0b1b54.chunk.js",
      "/34.4dbf1020b0ebea20b824.chunk.js",
      "/35.3d67c985481fbd867bd1.chunk.js",
      "/36.c6100ce120232de25139.chunk.js",
      "/37.3c13d505704578bba2e7.chunk.js",
      "/38.34732ba56b53c5818329.chunk.js",
      "/39.4d44aaa3c9b8edb39ab0.chunk.js",
      "/40.a27b52209f8941e36681.chunk.js",
      "/41.6413eb0def070cd4151f.chunk.js",
      "/42.8f49c912fc67d88ca6b8.chunk.js",
      "/43.aec292901573f542ccdd.chunk.js",
      "/44.594d7833ed62a547ad7c.chunk.js",
      "/45.4bfa8432f6f95d7d70f1.chunk.js",
      "/46.b4fd8a66d221a63bc983.chunk.js",
      "/47.c6f9484c9a8677e0bd2e.chunk.js",
      "/48.d5ce4a6129446090daf2.chunk.js",
      "/49.0ed9144b470f7cc874d4.chunk.js",
      "/50.d035780d623a9e33a5f5.chunk.js",
      "/51.876085ba7fbd9c05804c.chunk.js",
      "/52.4f24f884f1b13ff1fb46.chunk.js",
      "/53.6c1ead0c1cfde7c3e735.chunk.js",
      "/54.42f00cb88f6de8f14b8c.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "efc9492a290a2fb3720b3c5bb5a469775e693bbb": "/354b3e8b3d2379621200e26eb4b1511d.svg",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "a84acee44680d59931cba2c5114b0e030e8c5bcf": "/d4cbb847ebf68369bbe07d502d784812.png",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "e607857fef3cee608b4c99b026db0e7b013a33e5": "/npm.material-ui.030c26b72836fd1bf24d.chunk.js",
    "b7ade260840667b2040e4c9669ad747d34045a57": "/1.b8d5b51f34f8c7d44f1e.chunk.js",
    "f5e87438816b5457f914520e8f4d2f780291d281": "/2.4cc7a1436af6846aa4eb.chunk.js",
    "b01825e89b520d95c2253ecff506702789abc0c7": "/npm.css-loader.aaa01576ab27b146df4e.chunk.js",
    "dbb04ae199fcca114660e939032713f2a8499906": "/npm.intl.c5cd2291db52939a7222.chunk.js",
    "e8336abd55b558d6adcb0f63e5913da69d071202": "/5.c9fbbd1b6d4f2136d7f5.chunk.js",
    "3dcbb3d365dc50c8d7c7dc2cf551bc3b7e0261a4": "/6.f0a08d6c5a1f699fe1f4.chunk.js",
    "64201a39e8881f23843100db0c4fa5a90f28f74c": "/7.ce453b20d3eb23e49f4f.chunk.js",
    "dd285f088d582c4f4cba10a3f5970a634f62826b": "/main.b759765e5d489a228b99.chunk.js",
    "ea74706a76bf0f846e8ee9721c21a4b935656ba8": "/npm.axios.e0f7838f693ab463425d.chunk.js",
    "f2373485f437b9b93d8a7f58369f4f12dd406077": "/npm.babel.9f357335c0a55c905a97.chunk.js",
    "025a2ef8992e7a18c121eb69e48e4e65aca93089": "/npm.enquire.js.6c5716666d080501c1c0.chunk.js",
    "f1d2cbba9ea00f2ef7ce4cebb1f503c489b68ecc": "/npm.lodash.5b3072d46033a9d8e7e3.chunk.js",
    "df5d118440e249793f045a89e26a95b6f7abd50e": "/npm.react-app-polyfill.7ba3d8970fa918f815bb.chunk.js",
    "f94f7b03147f43c6298c7c31cf50110cb3e09879": "/npm.react-redux.c70dd14a0546014869b9.chunk.js",
    "7aebfa62cf88732084a34cf4e7f6975a202ac2bf": "/npm.react-slick.b19dea34bd64274dd0a8.chunk.js",
    "61e259dde4fe99ad4f572dcc41d77b9aff9808c4": "/npm.react-swipeable-views.0690c0d6469a1eb9938f.chunk.js",
    "1b2df265c154aa8ffd5ef4ff617e04cb9e39a47d": "/npm.react-swipeable-views-core.496e0a9bd69f05022390.chunk.js",
    "fbd6e925af43f02e23811a13a35b7ff7422517c1": "/npm.react-transition-group.909e5e254ff61fca54af.chunk.js",
    "35484f73e414c695b6986a8c9b4ddfcf938da9da": "/npm.slick-carousel.fd402ec6e7c2423d203d.chunk.js",
    "08d89b6c4f09358abaf29332e659700702319189": "/npm.video-react.aedd4582b562fa501bbd.chunk.js",
    "779980141f4db2db7d7c453f116cf8a32499be76": "/npm.warning.590e4a3c9c5315441224.chunk.js",
    "441a4c8ff08ea4b2e447c06ac27fcd8f9d1cc6d8": "/runtime.42156209062411e807de.js",
    "000e96dd7f11f083b61bc9ee96962f0fd073c3e1": "/23.58660d647c6cef9a9de7.chunk.js",
    "9fab8db084411bedfdfda28eb342aba4ca9d6a6d": "/24.318006029f1e04913f4f.chunk.js",
    "2359664df87a1486e8007c2c06d2c87e51583824": "/25.4f3ffb7c59be418067b8.chunk.js",
    "8ec68de8d87ecdf9f09793e6b63a16ac06d21ced": "/26.4708c482952b6da645a9.chunk.js",
    "de0a3686e4fb56fcd27c85dd30ed15d260f7d1ad": "/27.8e8050abafbb1403489d.chunk.js",
    "108dcddb5164f572b79d3b7dc5189e47f1a1029f": "/28.b68de3571cc541ceaf6a.chunk.js",
    "6708a4f5cf36539a0eaddf3217717542b6b21050": "/29.9c5f755b3c413d52c2c2.chunk.js",
    "a03fe5293ac26dd040b45c1f70ae987e296cb99a": "/30.92fea79277f277f10700.chunk.js",
    "f01b2c76c6e5247970e74ddeaee2a6e76a6ce60c": "/31.aefc299677a23137dcc8.chunk.js",
    "649db853cd82f91cfd77479933111daceba375cd": "/32.7d38040cf7f533b8fb35.chunk.js",
    "e81e31c75d210985997d93a1888d3564350d4336": "/33.cdd4659274b06a0b1b54.chunk.js",
    "394f2c694b9a26600ebfebbc4e5353ed70b542d7": "/34.4dbf1020b0ebea20b824.chunk.js",
    "8b7a940f64f00874063e551a6424c6a58a543b95": "/35.3d67c985481fbd867bd1.chunk.js",
    "0528b0fc54ec652439fcdb3a97bbc8b11c016517": "/36.c6100ce120232de25139.chunk.js",
    "566e9348365094e8f0391960ff08f5d5c68fc5ac": "/37.3c13d505704578bba2e7.chunk.js",
    "0bf4e0749b3d6dd2a849e3e9d700b72e05084d21": "/38.34732ba56b53c5818329.chunk.js",
    "735f9e92a853af881ba062d17d03151bfdd510a7": "/39.4d44aaa3c9b8edb39ab0.chunk.js",
    "99e99c550eff416cd3e2436da4b3d237cd4f48a0": "/40.a27b52209f8941e36681.chunk.js",
    "1609a4621e8fec64088673ebb702ee53ea205c86": "/41.6413eb0def070cd4151f.chunk.js",
    "52c0e982f99e50ba4a29da158587ffaf0e564554": "/42.8f49c912fc67d88ca6b8.chunk.js",
    "8a15ecf1fc94cf46b2249f9a4ec8d061ec4a0754": "/43.aec292901573f542ccdd.chunk.js",
    "d39959ce24d504eb810839d898274ea13aef32e3": "/44.594d7833ed62a547ad7c.chunk.js",
    "1ec1d4a473ee611d936adb5ca373aa9b114cfcaf": "/45.4bfa8432f6f95d7d70f1.chunk.js",
    "239a1ddf9ee5b91b9479897853cbb0ac8568f23d": "/46.b4fd8a66d221a63bc983.chunk.js",
    "90876125c95a78163ea94291e0d57ddfad125505": "/47.c6f9484c9a8677e0bd2e.chunk.js",
    "5148bef01cc9d116a87acd2a0c5d950b5e5e3f4b": "/48.d5ce4a6129446090daf2.chunk.js",
    "91b6c8933f3510d7bd5f32c43f5bd2b523746eff": "/49.0ed9144b470f7cc874d4.chunk.js",
    "589624b1813335d48e00ec1afb93e6858e4919bd": "/50.d035780d623a9e33a5f5.chunk.js",
    "1e6aedd8298385bb1613730c3cbe5ba3b49c2698": "/51.876085ba7fbd9c05804c.chunk.js",
    "2a5f2ab379fc2498cad1f011d650e448c291bf1e": "/52.4f24f884f1b13ff1fb46.chunk.js",
    "8a71aad1e4492beed618004af9bf374490c5266f": "/53.6c1ead0c1cfde7c3e735.chunk.js",
    "2d54a626a3487aa651b6ee2aaba56e47c06bd19e": "/54.42f00cb88f6de8f14b8c.chunk.js",
    "a44e080b4904f20aa5b9cf55c7a2fa2177bcd425": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "9/28/2020, 10:49:50 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });