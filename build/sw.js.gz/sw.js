var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/354b3e8b3d2379621200e26eb4b1511d.svg",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/d4cbb847ebf68369bbe07d502d784812.png",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/runtime.246d36123785e69ac2ec.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
      "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
      "/npm.lodash.deee929769997b4c230f.chunk.js",
      "/npm.react-fast-compare.91acf3ea3e27d38411d3.chunk.js",
      "/npm.material-ui.f4e78ce49e2ed74e3024.chunk.js",
      "/npm.intl.bccfaa29b51f45d8a373.chunk.js",
      "/main.013db82489cbee8e82da.chunk.js",
      "/npm.axios.02874dbbffe9856da5df.chunk.js",
      "/npm.babel.730c96fa87294c588392.chunk.js",
      "/npm.classnames.70e870328db288331070.chunk.js",
      "/npm.connected-react-router.31e8d869acddac75f6d5.chunk.js",
      "/npm.css-vendor.f995554cdbcac9992868.chunk.js",
      "/npm.dom-helpers.49d5bf33359c267bbcdd.chunk.js",
      "/npm.intl-messageformat.d6ceeb1666b40e85ecdb.chunk.js",
      "/npm.react-app-polyfill.975f665dcfb5627ee87c.chunk.js",
      "/npm.react-redux.fbc8608307a3b416c81c.chunk.js",
      "/npm.react-sizes.a16636e1a5ed7ddfed98.chunk.js",
      "/npm.react-transition-group.2860b6174aebd0bafd4b.chunk.js",
      "/npm.video-react.f3c4233bf96c0d1c3195.chunk.js",
      "/20.4b9a4dfb8b2abd835ef9.chunk.js",
      "/21.b7266634ac8ab9af0934.chunk.js",
      "/22.fd8e6cd0be17c9e6dbcb.chunk.js",
      "/23.56caea5e0af81d5017e7.chunk.js",
      "/24.2131a63a2538116ac467.chunk.js",
      "/25.857d14c771f0e31b0581.chunk.js",
      "/26.b445ce3d53a3a66c6473.chunk.js",
      "/27.64028eb04a5efd9f4717.chunk.js",
      "/28.64ff21983b2f2227da90.chunk.js",
      "/29.abf8e5dd9c5498865247.chunk.js",
      "/30.3924e4128726269ec744.chunk.js",
      "/31.3a0b0b09742f6825fe46.chunk.js",
      "/32.4240ec464be5f28b426a.chunk.js",
      "/33.905bc7c1a95f5facca64.chunk.js",
      "/34.e19359b1c1c9735dbe28.chunk.js",
      "/35.12919d5de823c611211f.chunk.js",
      "/36.115987120eecb7c44936.chunk.js",
      "/37.0bdb62a502c4880f1e33.chunk.js",
      "/38.b76c71762c3c8e741d76.chunk.js",
      "/39.7638732064bda10bf797.chunk.js",
      "/40.776d651639a5d35d9f84.chunk.js",
      "/41.f95a21d0a63497c3e111.chunk.js",
      "/42.e9c4bcf3f16f398ddf5a.chunk.js",
      "/43.ee64937329bf234f23d8.chunk.js",
      "/44.44e4703b9a4dd32ce952.chunk.js",
      "/45.0dad8b9c43932bd6d863.chunk.js",
      "/46.1308d131a3bcfd984988.chunk.js",
      "/47.1fb4fffd52cac08ed54e.chunk.js",
      "/48.2f8ec5f8ec6598066cf4.chunk.js",
      "/49.53be3a678a088ff6f4b4.chunk.js",
      "/50.1eb7bf6fa839ad3cca9f.chunk.js",
      "/51.52ba54f4c5ffab9fec68.chunk.js",
      "/52.25bc218a4dec3f0bbc27.chunk.js",
      "/53.baad7c6beeb51f5359b3.chunk.js",
      "/54.54646492027e8df8aacf.chunk.js",
      "/55.1df19bd2cacd0adeb48f.chunk.js",
      "/56.ffc6df2fc06529401cef.chunk.js",
      "/57.24858c354cfdaaf5af8b.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "efc9492a290a2fb3720b3c5bb5a469775e693bbb": "/354b3e8b3d2379621200e26eb4b1511d.svg",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "a84acee44680d59931cba2c5114b0e030e8c5bcf": "/d4cbb847ebf68369bbe07d502d784812.png",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
    "936d4bf9ea6e28e757f6d30ab22e1fbd78c7cc01": "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
    "2292c6ce3b5e909d2deb073787f607f6bc257f09": "/npm.lodash.deee929769997b4c230f.chunk.js",
    "698c4d824c278bd004665850012a0174b5680da8": "/npm.react-fast-compare.91acf3ea3e27d38411d3.chunk.js",
    "0b0fc7d805fb9cc73023788f827137c78edf31f5": "/npm.material-ui.f4e78ce49e2ed74e3024.chunk.js",
    "5ab7af351971bac84b1fa27c609789441af184ab": "/npm.intl.bccfaa29b51f45d8a373.chunk.js",
    "d0434e80698f8ac768c5e884703bcb1141d3ae36": "/main.013db82489cbee8e82da.chunk.js",
    "c5e62e5137dd753cf122fa19ab69d11ae3e64362": "/npm.axios.02874dbbffe9856da5df.chunk.js",
    "8a55354fddcc418804e00ec14983fb10d104afeb": "/npm.babel.730c96fa87294c588392.chunk.js",
    "945aff774c567e0a560fab77f765511ab6fd94ee": "/npm.classnames.70e870328db288331070.chunk.js",
    "3e5ab7416565b042c7401f19633375a28b11dd61": "/npm.connected-react-router.31e8d869acddac75f6d5.chunk.js",
    "5a8340f92daf8820c7f3cae5cfb94af4bd7d9efe": "/npm.css-vendor.f995554cdbcac9992868.chunk.js",
    "abacb7869162060020d50b5c87ba5e28005407fd": "/npm.dom-helpers.49d5bf33359c267bbcdd.chunk.js",
    "b0e587b8447b0a5947e7f86239170118fe6ebf93": "/npm.intl-messageformat.d6ceeb1666b40e85ecdb.chunk.js",
    "4cc8ea6f8532e03857239cf6e942bda15e7ec8cc": "/npm.react-app-polyfill.975f665dcfb5627ee87c.chunk.js",
    "3f37daad5a1df21da0f657b3566208577b341844": "/npm.react-redux.fbc8608307a3b416c81c.chunk.js",
    "a54b872eb6cf7a20cdc1101094e22227a80c2365": "/npm.react-sizes.a16636e1a5ed7ddfed98.chunk.js",
    "3026c6314966e40b672393f071aa8bb04ad50f0c": "/npm.react-transition-group.2860b6174aebd0bafd4b.chunk.js",
    "34f659ee14f8d5b4452252b3e9d36e5de2bd2bd8": "/npm.video-react.f3c4233bf96c0d1c3195.chunk.js",
    "48a96b19071217aa32836e923a22d87b4db11d68": "/runtime.246d36123785e69ac2ec.js",
    "53b9400856dd7c0252fe4cadd4f21710c0eae2b7": "/20.4b9a4dfb8b2abd835ef9.chunk.js",
    "bd5b36e22836891e5ae7c18cbb6e5a271c52dcf0": "/21.b7266634ac8ab9af0934.chunk.js",
    "b82f45bafee339d455b86afeaeb2d6a7b57b2449": "/22.fd8e6cd0be17c9e6dbcb.chunk.js",
    "a6385ef09a9892af0f85261879bfe689c76f1910": "/23.56caea5e0af81d5017e7.chunk.js",
    "00e05d128d701080d6d0adaeacf03486c1bfa42f": "/24.2131a63a2538116ac467.chunk.js",
    "615c443951211eea30bd36a354279e04d31940c1": "/25.857d14c771f0e31b0581.chunk.js",
    "97e1e3e2ab1d1514868216927dab8417c3c80708": "/26.b445ce3d53a3a66c6473.chunk.js",
    "1385474896c8db19c8ccad616015f77672af7313": "/27.64028eb04a5efd9f4717.chunk.js",
    "0d4ec49f6140c77cea58b5613c609babce66ffc2": "/28.64ff21983b2f2227da90.chunk.js",
    "6ffaa57e3e9b2b86db8453a72ac107d1e59bbf36": "/29.abf8e5dd9c5498865247.chunk.js",
    "9611694ec200ca97d29e16e69f0797f7a0b350bc": "/30.3924e4128726269ec744.chunk.js",
    "ae8b695a2cf0ad6e559e28f7c0851b03969bafdc": "/31.3a0b0b09742f6825fe46.chunk.js",
    "91b445e04efb77fa7b2abea86cbe8da7e23eb1b5": "/32.4240ec464be5f28b426a.chunk.js",
    "7037fa5f876c06bf67ad52f5fbffccd68810d2f3": "/33.905bc7c1a95f5facca64.chunk.js",
    "dcda59226b70f4694b94d66e68b87a32c3218faa": "/34.e19359b1c1c9735dbe28.chunk.js",
    "856825239984e6f2403e814e492dde4aafad50cf": "/35.12919d5de823c611211f.chunk.js",
    "eaee931734f21ee86f073f1485d5bc7fa885164e": "/36.115987120eecb7c44936.chunk.js",
    "6003bd7776d64dd0aaea0e5560df0b28cbeafb5a": "/37.0bdb62a502c4880f1e33.chunk.js",
    "7b40d8601b3a3328464b4fe27414bc5d647b6ff2": "/38.b76c71762c3c8e741d76.chunk.js",
    "9c1b946c4a4d9bb1b6ee9ac87dc4fcf6dff7f0c2": "/39.7638732064bda10bf797.chunk.js",
    "20efba1e2d01549994cf186bb483e13ef93490ba": "/40.776d651639a5d35d9f84.chunk.js",
    "82602cd025777176827978bd07181ab67b49e94b": "/41.f95a21d0a63497c3e111.chunk.js",
    "a095ffa86ea2636e87f7fc581962524d3a155e0d": "/42.e9c4bcf3f16f398ddf5a.chunk.js",
    "0f960ec28e397e20b42f18fd4f6c3154891a5f16": "/43.ee64937329bf234f23d8.chunk.js",
    "2e26ec6a30343227ab01b60774a5b80a4c52d14e": "/44.44e4703b9a4dd32ce952.chunk.js",
    "8e6e599c7e1f58c07ffe2cbf7c54ac525549af16": "/45.0dad8b9c43932bd6d863.chunk.js",
    "dd78b51c338c32b2a8dff0173d49c65ebd48565b": "/46.1308d131a3bcfd984988.chunk.js",
    "6a1883ba6206f19273876b9bce7e0bf64c8872d1": "/47.1fb4fffd52cac08ed54e.chunk.js",
    "15a3f6f93b966438f56cdd74e872008ae57b4fb9": "/48.2f8ec5f8ec6598066cf4.chunk.js",
    "cd25943d9e1deafb3d83f698c6d73a0ff2b319b3": "/49.53be3a678a088ff6f4b4.chunk.js",
    "6a4f0c80c79cd6c8288d0fe79d67885bb5d26fa1": "/50.1eb7bf6fa839ad3cca9f.chunk.js",
    "7db8b5e1319d594c1b42dc84a6b0b04e26872cbe": "/51.52ba54f4c5ffab9fec68.chunk.js",
    "8013acacfa9dbb692098022ac9aa681545195269": "/52.25bc218a4dec3f0bbc27.chunk.js",
    "34eaf65b9742beff8592d9f6c92e0feb3d3c3bb7": "/53.baad7c6beeb51f5359b3.chunk.js",
    "f3981b6c26a8bbbec79743395b9ff04395bff36c": "/54.54646492027e8df8aacf.chunk.js",
    "75b53f76924386fb7440163ade88592b6c7b1703": "/55.1df19bd2cacd0adeb48f.chunk.js",
    "7254e3a5adb92075d3746260bd82c100352f947c": "/56.ffc6df2fc06529401cef.chunk.js",
    "4064f6952f17b8e441dfd53106305a8b05cfd117": "/57.24858c354cfdaaf5af8b.chunk.js",
    "dc85d7b8e136766cc9c000898dd5b124b7c13f44": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "9/29/2020, 9:20:48 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });