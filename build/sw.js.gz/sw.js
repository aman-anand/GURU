var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/e924879b96f98562a3849d7b19e3c5d9.svg",
      "/bc220eaffb7267e5327ad14f1fb27319.png",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/d4cbb847ebf68369bbe07d502d784812.png",
      "/140cbb2312ccdb46c7d6631bb29159fd.svg",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/361d1fe064ca110510aa7839b6ec3bb2.svg",
      "/runtime.71502eef0f350a8432b0.js",
      "/"
    ],
    "additional": [
      "/npm.material-ui.782e4e2a5459cba030fb.chunk.js",
      "/npm.webpack.b7e1ba51e7f6ecb13483.chunk.js",
      "/npm.exenv.ee7dd97a0bc21866a65b.chunk.js",
      "/npm.lodash.18ae2af79a556bb6a762.chunk.js",
      "/npm.react-fast-compare.e08aba6401f5c59a2f6b.chunk.js",
      "/npm.dom-helpers.af5a55ff23085d74416b.chunk.js",
      "/npm.react-transition-group.39eb7a599016da905a0d.chunk.js",
      "/npm.babel.06610a66a9cbd8943d63.chunk.js",
      "/npm.final-form.852dad972a6183ebc9bf.chunk.js",
      "/npm.intl.9e59fd74d50402191fad.chunk.js",
      "/npm.react-final-form.aed8e4ff2d493258df67.chunk.js",
      "/11.68ffaa93acfa75171906.chunk.js",
      "/main.c0629489f50fed9ab3bf.chunk.js",
      "/npm.axios.75974b270943800f1e4e.chunk.js",
      "/npm.connected-react-router.50a5064aff54d6c1d409.chunk.js",
      "/npm.css-vendor.3c7f3463f387add85c70.chunk.js",
      "/npm.intl-messageformat.b9f03367493044342345.chunk.js",
      "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
      "/npm.react-lifecycles-compat.6c2859ed0eadab3916c6.chunk.js",
      "/npm.react-modal-video.0f0c94051032d4bd35e1.chunk.js",
      "/npm.react-redux.40a56e16553988c9bdc1.chunk.js",
      "/npm.react-sizes.ca4659067aecaa631bb5.chunk.js",
      "/23.13b63ffb0607e4db252f.chunk.js",
      "/24.9ad21b8099caf78fa295.chunk.js",
      "/25.877d050af5ee2a205490.chunk.js",
      "/26.e0e39c1de410f08cdedd.chunk.js",
      "/27.cb32c8ca194bae5b5a86.chunk.js",
      "/28.631434a38306adfaeb5e.chunk.js",
      "/29.0d5db80b5260eec0babd.chunk.js",
      "/30.dbe3c1fc2753328dce89.chunk.js",
      "/31.60276c4239ca1cb209d9.chunk.js",
      "/32.31cf2b1ad075ca9210bd.chunk.js",
      "/33.426c610a4ed8b805a809.chunk.js",
      "/34.a53d703b876edda9c952.chunk.js",
      "/35.664a542f5a4f21c6805c.chunk.js",
      "/36.12592cc3c18ec4e2b436.chunk.js",
      "/37.b831414dfef4fb14bcde.chunk.js",
      "/38.c3526d29748e2206471d.chunk.js",
      "/39.dfb6d1364ce7a94c0cfe.chunk.js",
      "/40.e03353731dbb9001b062.chunk.js",
      "/41.d95bdd8df696247310a8.chunk.js",
      "/42.3e037950f3357075287d.chunk.js",
      "/43.c0deb4b13340946d862a.chunk.js",
      "/44.8c17e24024cceba0c64d.chunk.js",
      "/45.01886a29286c784637a0.chunk.js",
      "/46.b56b0081d9d064025902.chunk.js",
      "/47.5f4fa117bb6f1886b6b6.chunk.js",
      "/48.54986fc286e7e3aabeaf.chunk.js",
      "/49.f8e2186b4001147c9174.chunk.js",
      "/50.01a80949957c6bfce08c.chunk.js",
      "/51.20b1197f107fda5d7d42.chunk.js",
      "/52.00e932bcbf03adfbb333.chunk.js",
      "/53.37108d863aa6c79aad5d.chunk.js",
      "/54.35db7422bd327623c3b1.chunk.js",
      "/55.76bf11783ecd6225feef.chunk.js",
      "/56.f5266af01c41ebb209b0.chunk.js",
      "/57.0c85201342a13cac2b67.chunk.js",
      "/58.12a2791a15db3235620f.chunk.js",
      "/59.e604984695c4b84303f1.chunk.js",
      "/60.fbc1b1dc308a10b12ea6.chunk.js",
      "/61.0143031676c94de62c22.chunk.js",
      "/62.2532831013a87cd9494a.chunk.js",
      "/63.f7d4500f1bbe9aa68b3e.chunk.js",
      "/64.ff7feb8aa3b8b8f685bf.chunk.js",
      "/65.e17cff82c19e445c6fcd.chunk.js",
      "/66.38a9c0b32362925811ee.chunk.js",
      "/67.66c48a9168c0114599c9.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "5777fda6ce1bad9b637b0e698c8bda118ae47e80": "/e924879b96f98562a3849d7b19e3c5d9.svg",
    "4d6210e78f44e1fdd5aed4bacdc853110ee78bf6": "/bc220eaffb7267e5327ad14f1fb27319.png",
    "e1bedfc6cd3a8cdac6785d7f2f6e1703829a8689": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "a84acee44680d59931cba2c5114b0e030e8c5bcf": "/d4cbb847ebf68369bbe07d502d784812.png",
    "b7f18933317bf5145b1942d26a33904e0f80ac5f": "/140cbb2312ccdb46c7d6631bb29159fd.svg",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "6fbf4468f7d09b7eb2c028f6dd7a35d751b0a33e": "/361d1fe064ca110510aa7839b6ec3bb2.svg",
    "bd95893db6c98905109f4bd5bc69b2106b355fc3": "/npm.material-ui.782e4e2a5459cba030fb.chunk.js",
    "7e8b365af072c84395f57e0f38da74b78401b795": "/npm.webpack.b7e1ba51e7f6ecb13483.chunk.js",
    "798ac859118ddc1508bed3a080210d040091a73e": "/npm.exenv.ee7dd97a0bc21866a65b.chunk.js",
    "1d424b262f9c4310a1a025aa574453cf87e538f9": "/npm.lodash.18ae2af79a556bb6a762.chunk.js",
    "39e9e4fb900e81b92a9f83597b060a22c5957a06": "/npm.react-fast-compare.e08aba6401f5c59a2f6b.chunk.js",
    "34a368724f0227a4d4188b21190bc6e07e03f530": "/npm.dom-helpers.af5a55ff23085d74416b.chunk.js",
    "0edb2986998d778e50b8407ddda44de945dcf2c2": "/npm.react-transition-group.39eb7a599016da905a0d.chunk.js",
    "923485d07715cb37b878ee7e10436928b9a11031": "/npm.babel.06610a66a9cbd8943d63.chunk.js",
    "fc4f5c9d0b95e974037c2c32350925648d8824a0": "/npm.final-form.852dad972a6183ebc9bf.chunk.js",
    "ccd406f357b04045858520bd50cc97a2d6098c5f": "/npm.intl.9e59fd74d50402191fad.chunk.js",
    "7c3f6b7ff07a2b52fe0f89818fc31221354be212": "/npm.react-final-form.aed8e4ff2d493258df67.chunk.js",
    "f5cb42bf0e602d2528280de6f28c3a64dc2a6727": "/11.68ffaa93acfa75171906.chunk.js",
    "bd69b8b94949ae9c812e10db2d1c3f59675f7a4e": "/main.c0629489f50fed9ab3bf.chunk.js",
    "a7aace07698421e684389263ffe18dcfe759e37e": "/npm.axios.75974b270943800f1e4e.chunk.js",
    "d58abf8cf55f11d7b751d9fc1ce9d863c7974e0a": "/npm.connected-react-router.50a5064aff54d6c1d409.chunk.js",
    "1fad670702b7b1da72c4219b56735b612d06089a": "/npm.css-vendor.3c7f3463f387add85c70.chunk.js",
    "fa90c86a413e561c4e7679987c04c4bced9feb44": "/npm.intl-messageformat.b9f03367493044342345.chunk.js",
    "6aa2bce4b04b5c348195ad5f80d3b482bc441b87": "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
    "6ccd26638bfd879ffdef2d4352e6ac85e52d91c0": "/npm.react-lifecycles-compat.6c2859ed0eadab3916c6.chunk.js",
    "171c1af18d967bc53c4ca77583729e8fa1e71792": "/npm.react-modal-video.0f0c94051032d4bd35e1.chunk.js",
    "d1beb5e49f0998d715ad272f8f6ebf1609da62ee": "/npm.react-redux.40a56e16553988c9bdc1.chunk.js",
    "2499ffdc6d0c2204214402c8cea5ba1e026c1430": "/npm.react-sizes.ca4659067aecaa631bb5.chunk.js",
    "a23d8bfa5148382ec4814109ea206764e35525e4": "/runtime.71502eef0f350a8432b0.js",
    "8f61d4c3ac94a7fe23da01b096fde7f984857a1d": "/23.13b63ffb0607e4db252f.chunk.js",
    "0847663ff73141782595927ad23e301399e2fbdf": "/24.9ad21b8099caf78fa295.chunk.js",
    "3abd0a85b4056f018aec7525375c6ec1b9709114": "/25.877d050af5ee2a205490.chunk.js",
    "f5c78c04b2edc6ee8ec7d7f1793619e8337efd53": "/26.e0e39c1de410f08cdedd.chunk.js",
    "eab45757efd8404434aaa29b326d591907a2dbf7": "/27.cb32c8ca194bae5b5a86.chunk.js",
    "56b69e3143afde96c7a6f2e060f4acf0a027faa0": "/28.631434a38306adfaeb5e.chunk.js",
    "472561eaafc36b559b5101fba6e2261e79bd2f29": "/29.0d5db80b5260eec0babd.chunk.js",
    "276db4f55fc4d573fa9607cc2aeb7ab7fea95c92": "/30.dbe3c1fc2753328dce89.chunk.js",
    "0b1a8338ba4603d3c40925914d4601d0cd6f2939": "/31.60276c4239ca1cb209d9.chunk.js",
    "a25031cbcb3904ff175a9447f8cf38ef0eb20bc1": "/32.31cf2b1ad075ca9210bd.chunk.js",
    "ae7aaebc189b4bf402bc0e2fae9b6a15134f0d8e": "/33.426c610a4ed8b805a809.chunk.js",
    "024cfc25d8eec2c315e23dc1bb73a055f438f51a": "/34.a53d703b876edda9c952.chunk.js",
    "c8a8525743d9149bd00aba8a221ce6dc85b22b2e": "/35.664a542f5a4f21c6805c.chunk.js",
    "95d894cdeaaf6a2ba7ebfacf5492523fb2c07ab0": "/36.12592cc3c18ec4e2b436.chunk.js",
    "aaa61fb35fe3046fb3dc1a23b53e4e8345612ed5": "/37.b831414dfef4fb14bcde.chunk.js",
    "86369d45b828ac584cd98dd96a3f707ddcc4ff1d": "/38.c3526d29748e2206471d.chunk.js",
    "0eb90be2b99ce15b78ca99e88731cbe16edefde4": "/39.dfb6d1364ce7a94c0cfe.chunk.js",
    "79caf6a910ee17143de26ff89bc0202af6764f7f": "/40.e03353731dbb9001b062.chunk.js",
    "6bb95884bc37c7e304cbee3f0e57d49979e5865e": "/41.d95bdd8df696247310a8.chunk.js",
    "1c7f6979e588f20290675cd87d0b5d68eb04a9b8": "/42.3e037950f3357075287d.chunk.js",
    "db89d407ed10526a19949e3f0a86c6cbb5b03a24": "/43.c0deb4b13340946d862a.chunk.js",
    "742016215f675671e5f813c5f7c6152d9f1808c1": "/44.8c17e24024cceba0c64d.chunk.js",
    "d8fb737e7bdbe983661fa00878dff6fc0d02e3d3": "/45.01886a29286c784637a0.chunk.js",
    "13cd55459eefcfcb942474c10ebda295ff7d4987": "/46.b56b0081d9d064025902.chunk.js",
    "6a5a1cbf0e176001037a71e73f0b6df3df3bae2f": "/47.5f4fa117bb6f1886b6b6.chunk.js",
    "24324103947adb0d24aa22700f70ff32264a362f": "/48.54986fc286e7e3aabeaf.chunk.js",
    "4884d952b6b53d185754b8ca8d6f66dd36ebb353": "/49.f8e2186b4001147c9174.chunk.js",
    "9ae6cc1cef40548dd56f5bb0162e2fae3b81b059": "/50.01a80949957c6bfce08c.chunk.js",
    "018692cecbf6bb992fa77aa166ea6714871d47fe": "/51.20b1197f107fda5d7d42.chunk.js",
    "fa40f2dec54222f0fb1d96d8bec8ce127995a510": "/52.00e932bcbf03adfbb333.chunk.js",
    "8d823717930224d3d8facf87f3f816e568703838": "/53.37108d863aa6c79aad5d.chunk.js",
    "c43627a6c517b5b35900aedc8f887e0b8769888a": "/54.35db7422bd327623c3b1.chunk.js",
    "4ffd616e9463e510205afedbc8477a4d78d94e9d": "/55.76bf11783ecd6225feef.chunk.js",
    "1b4ce615d7ec899e82c176ab028665249e0ac5f0": "/56.f5266af01c41ebb209b0.chunk.js",
    "37867f9c38872e33826b7a1550a14920b59a54f4": "/57.0c85201342a13cac2b67.chunk.js",
    "ed16937fb96d697fcafbcd2086118292914fb442": "/58.12a2791a15db3235620f.chunk.js",
    "98f8219e3659b55b516a9dd6478de025cee1c401": "/59.e604984695c4b84303f1.chunk.js",
    "bb9c3082285ed87a20265c4a065f7ab8b7931f83": "/60.fbc1b1dc308a10b12ea6.chunk.js",
    "237b8698db207203b08911bbcbfb537f61b819e2": "/61.0143031676c94de62c22.chunk.js",
    "51d5407c6d83604610a76f974125c1bb85cbe312": "/62.2532831013a87cd9494a.chunk.js",
    "37b3cdfb0f3888f4a61622e40dc5070549521655": "/63.f7d4500f1bbe9aa68b3e.chunk.js",
    "d0477973e11b19a7fc085bed90bc5e99591e2ac6": "/64.ff7feb8aa3b8b8f685bf.chunk.js",
    "e583282f1cac6fb8b1bc74a82f90918b89bcc5ba": "/65.e17cff82c19e445c6fcd.chunk.js",
    "b962d451a3c9d65e4a95e42dde9867a5287cec09": "/66.38a9c0b32362925811ee.chunk.js",
    "5c834d237a57a511c1a6be7f83f20b80fb4ff7ff": "/67.66c48a9168c0114599c9.chunk.js",
    "92dda8f8efbaec138ca25094716270e046489351": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "12/26/2020, 11:58:10 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });