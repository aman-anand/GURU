var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/e924879b96f98562a3849d7b19e3c5d9.svg",
      "/354b3e8b3d2379621200e26eb4b1511d.svg",
      "/bc220eaffb7267e5327ad14f1fb27319.png",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/d4cbb847ebf68369bbe07d502d784812.png",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/361d1fe064ca110510aa7839b6ec3bb2.svg",
      "/runtime.53ed8167f6b821cd0241.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
      "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
      "/npm.lodash.deee929769997b4c230f.chunk.js",
      "/npm.material-ui.ab1ea002cfca981150a4.chunk.js",
      "/npm.react-fast-compare.e08aba6401f5c59a2f6b.chunk.js",
      "/npm.final-form.0870e2dbc0aac32af502.chunk.js",
      "/npm.intl.328b1cd34fe6b5be8110.chunk.js",
      "/npm.react-final-form.059a4f1c8089c2c51ad4.chunk.js",
      "/8.11a3fcb2611ae13761a9.chunk.js",
      "/main.28cb422cab50556ce6d7.chunk.js",
      "/npm.axios.361bddbc7b2ce31b3f16.chunk.js",
      "/npm.babel.70ef902b3592b3fd4706.chunk.js",
      "/npm.classnames.bbfddfe08e0db52f4fe4.chunk.js",
      "/npm.connected-react-router.ccf5c49e5785f5a02b8a.chunk.js",
      "/npm.css-vendor.14fc7c85b3de315aa965.chunk.js",
      "/npm.dom-helpers.bb3d3f413fafbca7b0cd.chunk.js",
      "/npm.intl-messageformat.b9f03367493044342345.chunk.js",
      "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
      "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
      "/npm.react-sizes.ab7e836d0d5874b5c395.chunk.js",
      "/npm.react-transition-group.bad2f3f7852436f1aae2.chunk.js",
      "/npm.video-react.f9c145d863ed2775f179.chunk.js",
      "/23.43b4a50e45adf2252eb0.chunk.js",
      "/24.f22e9206474763527ba9.chunk.js",
      "/25.331a27d4179f8cd7853e.chunk.js",
      "/26.afeff0a43212ad484675.chunk.js",
      "/27.fdb38eafdfcad710f5cc.chunk.js",
      "/28.8a889c452b14eaaef74a.chunk.js",
      "/29.bf64be3a013638e8133d.chunk.js",
      "/30.93afe0beb70908b31239.chunk.js",
      "/31.bb5d4bc1d1448e4f4c72.chunk.js",
      "/32.e333d54bad50ea263a95.chunk.js",
      "/33.3b5ae4c016969d363ae7.chunk.js",
      "/34.4d5f0df8228e523369b2.chunk.js",
      "/35.dc1fc79544b816d69aca.chunk.js",
      "/36.aafa37297dcb1b37195c.chunk.js",
      "/37.d4bc9426305ed11d3fd4.chunk.js",
      "/38.a329f91b154b523e6d0b.chunk.js",
      "/39.382f462340115552258a.chunk.js",
      "/40.b7588c4e5bc46d96db53.chunk.js",
      "/41.174b9290ae0cd1bf91c1.chunk.js",
      "/42.3e037950f3357075287d.chunk.js",
      "/43.8f3f3e1874ba5d127a21.chunk.js",
      "/44.94c8b301d38fd3830fa7.chunk.js",
      "/45.5afb7cf2c2558fa4ce5d.chunk.js",
      "/46.0ea8c092410ade024727.chunk.js",
      "/47.5b51321035227ae0e0b7.chunk.js",
      "/48.f948b4a1c5b22aa75e43.chunk.js",
      "/49.3a22b3a804ecea429c6d.chunk.js",
      "/50.2eca7d9f2cf0695bad11.chunk.js",
      "/51.4101ee342d99548d4aca.chunk.js",
      "/52.9a27dffd7ed8f800e785.chunk.js",
      "/53.82a08b2e47ccf3f652c3.chunk.js",
      "/54.da4895227780e8b674c2.chunk.js",
      "/55.292864f17a192c93d2e4.chunk.js",
      "/56.b0acf4137de390ecdbd9.chunk.js",
      "/57.082b1a99a29f8a028418.chunk.js",
      "/58.672ba5a977710b24a0cc.chunk.js",
      "/59.7f272424cde7bf1e61e1.chunk.js",
      "/60.30a544a2f7f5bd4fc4c4.chunk.js",
      "/61.298069d027cb48e9bfad.chunk.js",
      "/62.82b77d47b81c1fa2949e.chunk.js",
      "/63.3eb3fc260081a15d64b8.chunk.js",
      "/64.1a8368e1ee3a16dbab7b.chunk.js",
      "/65.6243a950add0c810b4a7.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "5777fda6ce1bad9b637b0e698c8bda118ae47e80": "/e924879b96f98562a3849d7b19e3c5d9.svg",
    "efc9492a290a2fb3720b3c5bb5a469775e693bbb": "/354b3e8b3d2379621200e26eb4b1511d.svg",
    "4d6210e78f44e1fdd5aed4bacdc853110ee78bf6": "/bc220eaffb7267e5327ad14f1fb27319.png",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "a84acee44680d59931cba2c5114b0e030e8c5bcf": "/d4cbb847ebf68369bbe07d502d784812.png",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "6fbf4468f7d09b7eb2c028f6dd7a35d751b0a33e": "/361d1fe064ca110510aa7839b6ec3bb2.svg",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
    "936d4bf9ea6e28e757f6d30ab22e1fbd78c7cc01": "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
    "2292c6ce3b5e909d2deb073787f607f6bc257f09": "/npm.lodash.deee929769997b4c230f.chunk.js",
    "12f6480da4930f96eee6920896a73f3816eae176": "/npm.material-ui.ab1ea002cfca981150a4.chunk.js",
    "39e9e4fb900e81b92a9f83597b060a22c5957a06": "/npm.react-fast-compare.e08aba6401f5c59a2f6b.chunk.js",
    "92d1f368c8b0ac6bcbf9c248114d13ae5a6578e5": "/npm.final-form.0870e2dbc0aac32af502.chunk.js",
    "5dd644301b05a77d01e34f4a1a2902b83045d984": "/npm.intl.328b1cd34fe6b5be8110.chunk.js",
    "ace48fe639049e62c5841353187fb73327521814": "/npm.react-final-form.059a4f1c8089c2c51ad4.chunk.js",
    "551c1f6e88191c9a7d8532210f632f6a0282d5c6": "/8.11a3fcb2611ae13761a9.chunk.js",
    "ea94616fc5ea440658432b442226e9063bca77c7": "/main.28cb422cab50556ce6d7.chunk.js",
    "0ea22a745ec487f05837dc0b57b82f3c66a81926": "/npm.axios.361bddbc7b2ce31b3f16.chunk.js",
    "8c5da80d93d525e0314d418afc731f22c5395473": "/npm.babel.70ef902b3592b3fd4706.chunk.js",
    "6daf73872ffaeb8848e2357629b6785ed3d416dc": "/npm.classnames.bbfddfe08e0db52f4fe4.chunk.js",
    "f73db0534017c675364b4e516c114c731bd8b88c": "/npm.connected-react-router.ccf5c49e5785f5a02b8a.chunk.js",
    "5af02a3a7b303877508a80fa597cd4db5e558aea": "/npm.css-vendor.14fc7c85b3de315aa965.chunk.js",
    "46750a3feb20a2dc4f14ea30928d732b9f18946a": "/npm.dom-helpers.bb3d3f413fafbca7b0cd.chunk.js",
    "fa90c86a413e561c4e7679987c04c4bced9feb44": "/npm.intl-messageformat.b9f03367493044342345.chunk.js",
    "6aa2bce4b04b5c348195ad5f80d3b482bc441b87": "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
    "2d3d4842d3f023f40286bf66ea301ee02bf85483": "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
    "8bde8a6e0accfcde781d6e92f3dfbff0b4f07483": "/npm.react-sizes.ab7e836d0d5874b5c395.chunk.js",
    "e7740dd18016c7f207ed4a78b7f1ee12858c2c6c": "/npm.react-transition-group.bad2f3f7852436f1aae2.chunk.js",
    "07563f526eff64ca6dae717fe4f9826ec727b042": "/npm.video-react.f9c145d863ed2775f179.chunk.js",
    "5a325ea3f5f0744a9dcf40db7b17c1d284e1793f": "/runtime.53ed8167f6b821cd0241.js",
    "97a1fe0f46a9a50579286021b3521449a6afe90b": "/23.43b4a50e45adf2252eb0.chunk.js",
    "687992538bbc8f1e7aad8acdbc2ff089628b1ef4": "/24.f22e9206474763527ba9.chunk.js",
    "ae0060e423b892509a2d277cf4d8683c72fc2efc": "/25.331a27d4179f8cd7853e.chunk.js",
    "8afb1b99117b8cf57f49a5d09a4267f6a82d9f7b": "/26.afeff0a43212ad484675.chunk.js",
    "acd8123b09491c7ca5ed176520ecbea0f32a3b93": "/27.fdb38eafdfcad710f5cc.chunk.js",
    "540ac3d7a46ea3c40213595e5f6855b6fd43538c": "/28.8a889c452b14eaaef74a.chunk.js",
    "56749c39f55921edc62b10754c080a759770a34a": "/29.bf64be3a013638e8133d.chunk.js",
    "4fbd26a46d974aa01e62e05a7978ed1ffdc737ff": "/30.93afe0beb70908b31239.chunk.js",
    "6afb6d3ab74c82e90f091081a9f3d53f098b9f34": "/31.bb5d4bc1d1448e4f4c72.chunk.js",
    "75eef4cacdeee978b44932ffbb731e57e494d154": "/32.e333d54bad50ea263a95.chunk.js",
    "45fc9ebdf8743ec3e7520cc035f43b37224462a3": "/33.3b5ae4c016969d363ae7.chunk.js",
    "ee01ec00b9bc555351c5869080c6dabd0e526193": "/34.4d5f0df8228e523369b2.chunk.js",
    "10e5d8d2ad07dca66806710b703e0b1f402d62de": "/35.dc1fc79544b816d69aca.chunk.js",
    "3119cd4b63b77ba7ec13320e3fd1c2e47614d7bd": "/36.aafa37297dcb1b37195c.chunk.js",
    "f342e08a855969e97af5a0964db03847987a5314": "/37.d4bc9426305ed11d3fd4.chunk.js",
    "75eda8efe40168b5b1036929c300a2916fcf7459": "/38.a329f91b154b523e6d0b.chunk.js",
    "bb85f267e400fb46b85e9939d36a1769c508ac1d": "/39.382f462340115552258a.chunk.js",
    "27db339cf11c3d1ea5799212cf75117cdc155920": "/40.b7588c4e5bc46d96db53.chunk.js",
    "46ced2d9eb30f4b83346e1e385a812a88fae771f": "/41.174b9290ae0cd1bf91c1.chunk.js",
    "1c7f6979e588f20290675cd87d0b5d68eb04a9b8": "/42.3e037950f3357075287d.chunk.js",
    "2b9d3d4d5dc6212db6be1189a62671fba878f516": "/43.8f3f3e1874ba5d127a21.chunk.js",
    "ab692469e06eb9b9d174914aec9e77168e392c9b": "/44.94c8b301d38fd3830fa7.chunk.js",
    "0309f861abd1d307dfe489132b762335e7731c31": "/45.5afb7cf2c2558fa4ce5d.chunk.js",
    "7fa17898bb4e42b89b70a3940cdf8a4e071304e9": "/46.0ea8c092410ade024727.chunk.js",
    "a5405f2009f0f3b612bb5e71654ad57ed7e865cf": "/47.5b51321035227ae0e0b7.chunk.js",
    "f1e6974c851e650591b75031667d5b26e18ff686": "/48.f948b4a1c5b22aa75e43.chunk.js",
    "1fa8f9bf01a118f7418495bfb7ba44b75e7f00d2": "/49.3a22b3a804ecea429c6d.chunk.js",
    "2f269a876e36bcbfb110567b3547696bf45f8bd8": "/50.2eca7d9f2cf0695bad11.chunk.js",
    "621ad1ea82cc2296bcfabfad00eac182928d2332": "/51.4101ee342d99548d4aca.chunk.js",
    "23cde474787bad78347a5272b90458c69c1bae68": "/52.9a27dffd7ed8f800e785.chunk.js",
    "631004ebb6f023411569faae2010eb65a5cd66ca": "/53.82a08b2e47ccf3f652c3.chunk.js",
    "b25cac614a8d051142e062e6b9bd0165d12ca932": "/54.da4895227780e8b674c2.chunk.js",
    "da6e6b79b0d40a4ffbc642da19773e73bfc520cc": "/55.292864f17a192c93d2e4.chunk.js",
    "2a1390569c0987eac1f5123d985aa31f67636249": "/56.b0acf4137de390ecdbd9.chunk.js",
    "7ef215c11e25f0b9cce52bb6a72bd6c31c1125a6": "/57.082b1a99a29f8a028418.chunk.js",
    "9cdb14d10eadc43ad968a1bd92d799eea43d9f36": "/58.672ba5a977710b24a0cc.chunk.js",
    "b7090e47378e304ed331f67f4b53e4105ddad759": "/59.7f272424cde7bf1e61e1.chunk.js",
    "47d1cfc4542dbbc78594454a07c0f18d7c51b168": "/60.30a544a2f7f5bd4fc4c4.chunk.js",
    "3ae99da806f6e5771d1f016bdb798c59d71a209e": "/61.298069d027cb48e9bfad.chunk.js",
    "c6797a9a0804a87b3979fe2c789f9cd2a61164ce": "/62.82b77d47b81c1fa2949e.chunk.js",
    "2bec5429ed38670a03c392ba16926c408abeb179": "/63.3eb3fc260081a15d64b8.chunk.js",
    "5d2c0ff85dc0596a149d484c50ed5e583a3d5086": "/64.1a8368e1ee3a16dbab7b.chunk.js",
    "f677f362263933f6537cf6e931568e00ded2778b": "/65.6243a950add0c810b4a7.chunk.js",
    "be5ccafd743111f0d7277f8ca5513d45639af536": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "10/25/2020, 6:12:31 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });