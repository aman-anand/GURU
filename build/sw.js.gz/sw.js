var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/e924879b96f98562a3849d7b19e3c5d9.svg",
      "/bc220eaffb7267e5327ad14f1fb27319.png",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/d4cbb847ebf68369bbe07d502d784812.png",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/361d1fe064ca110510aa7839b6ec3bb2.svg",
      "/runtime.6656d394a92f8fafbd76.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
      "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
      "/npm.lodash.deee929769997b4c230f.chunk.js",
      "/npm.react-fast-compare.91acf3ea3e27d38411d3.chunk.js",
      "/npm.material-ui.a046b67f48622c607144.chunk.js",
      "/npm.babel.e665309556dc817903ef.chunk.js",
      "/npm.final-form.d3038e5f1277e5e5abb2.chunk.js",
      "/npm.intl.8da3564e062e647a9e12.chunk.js",
      "/npm.react-final-form.a7c7231fc67f5158e4ad.chunk.js",
      "/9.44ff6ce451fc033cce90.chunk.js",
      "/main.64b41880e27fdf7d5983.chunk.js",
      "/npm.axios.a19c5d7d2d686331e346.chunk.js",
      "/npm.connected-react-router.fbdc44c52ef4c0fe8d65.chunk.js",
      "/npm.css-vendor.cce246afbdba27828561.chunk.js",
      "/npm.dom-helpers.18e383574e4d7a10a0dc.chunk.js",
      "/npm.intl-messageformat.0d2356167ca637b3e904.chunk.js",
      "/npm.react-app-polyfill.b32943fb1bcf15165934.chunk.js",
      "/npm.react-lifecycles-compat.9753812c6a337a5436c0.chunk.js",
      "/npm.react-modal-video.0ba0f359968470de45e2.chunk.js",
      "/npm.react-redux.106ecf34b708ec5c3c02.chunk.js",
      "/npm.react-sizes.5db7ea6ea5e9a62635ec.chunk.js",
      "/npm.react-transition-group.0be86cfee6a3f30564c2.chunk.js",
      "/23.294d5be4def51e86c592.chunk.js",
      "/24.84da818e2771fac8cfeb.chunk.js",
      "/25.6c321c55ed5924bb4d83.chunk.js",
      "/26.3e9573deefacb0714488.chunk.js",
      "/27.f5f54f8165f58d65d02d.chunk.js",
      "/28.fc4d8247db7f18784f1a.chunk.js",
      "/29.04f87c56e20381912a6c.chunk.js",
      "/30.abdb3e3b335594b4ca27.chunk.js",
      "/31.fadea081ad832a83b538.chunk.js",
      "/32.84d9e3b9eb0fc49b0016.chunk.js",
      "/33.7c92f929e81d45b158b3.chunk.js",
      "/34.d4dc235f77bfd1818364.chunk.js",
      "/35.0cc3fc56fa8ea4dba0e6.chunk.js",
      "/36.8732b0c9f986f687e261.chunk.js",
      "/37.5da827ace815292ffd53.chunk.js",
      "/38.58fb19b89b88b313c38a.chunk.js",
      "/39.4af24a5f04bdf1b4401a.chunk.js",
      "/40.b7588c4e5bc46d96db53.chunk.js",
      "/41.76c606f4f9405b009b07.chunk.js",
      "/42.3e037950f3357075287d.chunk.js",
      "/43.4da04937188142163b68.chunk.js",
      "/44.94c8b301d38fd3830fa7.chunk.js",
      "/45.5afb7cf2c2558fa4ce5d.chunk.js",
      "/46.0ea8c092410ade024727.chunk.js",
      "/47.7527d1f14ab366982867.chunk.js",
      "/48.f948b4a1c5b22aa75e43.chunk.js",
      "/49.3a22b3a804ecea429c6d.chunk.js",
      "/50.2eca7d9f2cf0695bad11.chunk.js",
      "/51.4101ee342d99548d4aca.chunk.js",
      "/52.9a27dffd7ed8f800e785.chunk.js",
      "/53.9b406a9a841cf59d6f94.chunk.js",
      "/54.da4895227780e8b674c2.chunk.js",
      "/55.292864f17a192c93d2e4.chunk.js",
      "/56.8f5b780185458b3eac0c.chunk.js",
      "/57.082b1a99a29f8a028418.chunk.js",
      "/58.672ba5a977710b24a0cc.chunk.js",
      "/59.7f272424cde7bf1e61e1.chunk.js",
      "/60.30a544a2f7f5bd4fc4c4.chunk.js",
      "/61.4d2e40927efbc3a80b76.chunk.js",
      "/62.82b77d47b81c1fa2949e.chunk.js",
      "/63.6afc8c3b7f38064a2ea8.chunk.js",
      "/64.1a8368e1ee3a16dbab7b.chunk.js",
      "/65.6243a950add0c810b4a7.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "5777fda6ce1bad9b637b0e698c8bda118ae47e80": "/e924879b96f98562a3849d7b19e3c5d9.svg",
    "4d6210e78f44e1fdd5aed4bacdc853110ee78bf6": "/bc220eaffb7267e5327ad14f1fb27319.png",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "a84acee44680d59931cba2c5114b0e030e8c5bcf": "/d4cbb847ebf68369bbe07d502d784812.png",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "6fbf4468f7d09b7eb2c028f6dd7a35d751b0a33e": "/361d1fe064ca110510aa7839b6ec3bb2.svg",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
    "936d4bf9ea6e28e757f6d30ab22e1fbd78c7cc01": "/npm.exenv.9e5c2cd1c052e141a968.chunk.js",
    "2292c6ce3b5e909d2deb073787f607f6bc257f09": "/npm.lodash.deee929769997b4c230f.chunk.js",
    "698c4d824c278bd004665850012a0174b5680da8": "/npm.react-fast-compare.91acf3ea3e27d38411d3.chunk.js",
    "82898c6c495896e3319b77241da1d3fdcf7d8e92": "/npm.material-ui.a046b67f48622c607144.chunk.js",
    "d88175c5a252695b579a88bc82d964dc03bad909": "/npm.babel.e665309556dc817903ef.chunk.js",
    "d4ba1c1c0dfa95c2443d5f48cc86e7b9173bf8ee": "/npm.final-form.d3038e5f1277e5e5abb2.chunk.js",
    "473c59d62481ddcfd9a292e538e2303b53744cf7": "/npm.intl.8da3564e062e647a9e12.chunk.js",
    "80fcc512976c14c69c4613a08df036b20afa06b1": "/npm.react-final-form.a7c7231fc67f5158e4ad.chunk.js",
    "ee555c132ed3882c29739077356d70f7e1b8fa8f": "/9.44ff6ce451fc033cce90.chunk.js",
    "4294a346da96b7e6c1c55d70ffc11aa3931ceb00": "/main.64b41880e27fdf7d5983.chunk.js",
    "3647a76e33a1e6105ac9d9c01d9d0f1825fd249a": "/npm.axios.a19c5d7d2d686331e346.chunk.js",
    "d4d2d6611cd08467c6972e94ed301ac297ad9d7d": "/npm.connected-react-router.fbdc44c52ef4c0fe8d65.chunk.js",
    "039f61b281a155e65ba71db348ce22e72e53955b": "/npm.css-vendor.cce246afbdba27828561.chunk.js",
    "6bb3165128ea28a224271b4f6d29cfe7b0e82a9b": "/npm.dom-helpers.18e383574e4d7a10a0dc.chunk.js",
    "ba367d70cc921b5cb223ff366c142eb5a441bede": "/npm.intl-messageformat.0d2356167ca637b3e904.chunk.js",
    "9162210ef59e510a255256aeae04480f86674824": "/npm.react-app-polyfill.b32943fb1bcf15165934.chunk.js",
    "cf67057ac06fa4a557a6206da1aa546a26f08e5d": "/npm.react-lifecycles-compat.9753812c6a337a5436c0.chunk.js",
    "fe3a987c20254945039d837b96544adcb4bc4ea2": "/npm.react-modal-video.0ba0f359968470de45e2.chunk.js",
    "17cd2e7b1554efe0a5245253ad9d9b2c0a13a522": "/npm.react-redux.106ecf34b708ec5c3c02.chunk.js",
    "7dfdcd72a975d8e22706025fa7e8031f3614d14f": "/npm.react-sizes.5db7ea6ea5e9a62635ec.chunk.js",
    "2fd95e159dec0e0c2c40351d325d22eb12304441": "/npm.react-transition-group.0be86cfee6a3f30564c2.chunk.js",
    "ea594f3ef163bc8770d9e29bdc0f0278c0bbb788": "/runtime.6656d394a92f8fafbd76.js",
    "ff0233485f3f0ae555ec20cd4181c07361a87f3a": "/23.294d5be4def51e86c592.chunk.js",
    "599974f2b22522c2b02d5ab09e39ce853bd21cd3": "/24.84da818e2771fac8cfeb.chunk.js",
    "93a17cc6ef03b6814edb81e3bb4e9605f90388e9": "/25.6c321c55ed5924bb4d83.chunk.js",
    "28b785ce11114818da70fcb846ad7779f83ff546": "/26.3e9573deefacb0714488.chunk.js",
    "6f8d7b032e57c6a16304fcd85608603e66b1e265": "/27.f5f54f8165f58d65d02d.chunk.js",
    "1b879699ba214b9d66417a493f005ebd238597a8": "/28.fc4d8247db7f18784f1a.chunk.js",
    "baf102d7c545c351fc38ed43f7589d019120b2c2": "/29.04f87c56e20381912a6c.chunk.js",
    "bd7d79f336d6d5ab2a45fa84f9946dd569f3ab87": "/30.abdb3e3b335594b4ca27.chunk.js",
    "05ba7d8c016970cece74ce8a9e6fb6898efc72f2": "/31.fadea081ad832a83b538.chunk.js",
    "73691f26a2364074303e53beb3a4d8d853b4923b": "/32.84d9e3b9eb0fc49b0016.chunk.js",
    "03d3c1af7164fbe903b27bd96e212bed21f53263": "/33.7c92f929e81d45b158b3.chunk.js",
    "523e4dcc11093281f006ced0d4ee71d55da6e87a": "/34.d4dc235f77bfd1818364.chunk.js",
    "227e96bbf74d2178f46e57541b6d2b5a2e4a0b43": "/35.0cc3fc56fa8ea4dba0e6.chunk.js",
    "e103e70c179e2a73c9311619b2c458ad2849f1e4": "/36.8732b0c9f986f687e261.chunk.js",
    "d7559d3b4327591783417c484165c3b18866d2c1": "/37.5da827ace815292ffd53.chunk.js",
    "765eb8af009a2a643f40e1a68ac0476204feb63c": "/38.58fb19b89b88b313c38a.chunk.js",
    "ea124d5fc632edcce7c7e3c750b117f2a8383d69": "/39.4af24a5f04bdf1b4401a.chunk.js",
    "27db339cf11c3d1ea5799212cf75117cdc155920": "/40.b7588c4e5bc46d96db53.chunk.js",
    "d505d0c8bbf3fcafafe98225ebb348ccac2ba83c": "/41.76c606f4f9405b009b07.chunk.js",
    "1c7f6979e588f20290675cd87d0b5d68eb04a9b8": "/42.3e037950f3357075287d.chunk.js",
    "f827d45aeb08c41071dcb4801d34549b7682e8a0": "/43.4da04937188142163b68.chunk.js",
    "ab692469e06eb9b9d174914aec9e77168e392c9b": "/44.94c8b301d38fd3830fa7.chunk.js",
    "0309f861abd1d307dfe489132b762335e7731c31": "/45.5afb7cf2c2558fa4ce5d.chunk.js",
    "7fa17898bb4e42b89b70a3940cdf8a4e071304e9": "/46.0ea8c092410ade024727.chunk.js",
    "2828bdedc8db06b22dca91cd82c85bd99d7d1660": "/47.7527d1f14ab366982867.chunk.js",
    "f1e6974c851e650591b75031667d5b26e18ff686": "/48.f948b4a1c5b22aa75e43.chunk.js",
    "1fa8f9bf01a118f7418495bfb7ba44b75e7f00d2": "/49.3a22b3a804ecea429c6d.chunk.js",
    "2f269a876e36bcbfb110567b3547696bf45f8bd8": "/50.2eca7d9f2cf0695bad11.chunk.js",
    "621ad1ea82cc2296bcfabfad00eac182928d2332": "/51.4101ee342d99548d4aca.chunk.js",
    "23cde474787bad78347a5272b90458c69c1bae68": "/52.9a27dffd7ed8f800e785.chunk.js",
    "bd9e26bbbe19e15573878ae7f0a6636353096350": "/53.9b406a9a841cf59d6f94.chunk.js",
    "b25cac614a8d051142e062e6b9bd0165d12ca932": "/54.da4895227780e8b674c2.chunk.js",
    "da6e6b79b0d40a4ffbc642da19773e73bfc520cc": "/55.292864f17a192c93d2e4.chunk.js",
    "488039a7257b67ecd13b59fd412ce2defecdb97b": "/56.8f5b780185458b3eac0c.chunk.js",
    "7ef215c11e25f0b9cce52bb6a72bd6c31c1125a6": "/57.082b1a99a29f8a028418.chunk.js",
    "9cdb14d10eadc43ad968a1bd92d799eea43d9f36": "/58.672ba5a977710b24a0cc.chunk.js",
    "b7090e47378e304ed331f67f4b53e4105ddad759": "/59.7f272424cde7bf1e61e1.chunk.js",
    "47d1cfc4542dbbc78594454a07c0f18d7c51b168": "/60.30a544a2f7f5bd4fc4c4.chunk.js",
    "94a59fe2dc411f6fa5d786a999e241934b17eb0e": "/61.4d2e40927efbc3a80b76.chunk.js",
    "c6797a9a0804a87b3979fe2c789f9cd2a61164ce": "/62.82b77d47b81c1fa2949e.chunk.js",
    "49e3ebcab07d87b1679e849ff8ac06e74d3606ac": "/63.6afc8c3b7f38064a2ea8.chunk.js",
    "5d2c0ff85dc0596a149d484c50ed5e583a3d5086": "/64.1a8368e1ee3a16dbab7b.chunk.js",
    "f677f362263933f6537cf6e931568e00ded2778b": "/65.6243a950add0c810b4a7.chunk.js",
    "97319d5be4e1c08011a85637f30ae73003215337": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "11/2/2020, 8:21:43 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });