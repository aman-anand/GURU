var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/ced611daf7709cc778da928fec876475.eot",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/354b3e8b3d2379621200e26eb4b1511d.svg",
      "/favicon.ico",
      "/92c9db83163207f1b8239ea93c890951.png",
      "/45dae1f852dab39e3c142ffe41f12eea.png",
      "/cb01bfd5df2c0bb8b3ee06a8e2bb256c.jpg",
      "/c6bbb1c9229f10e2616370ff295f2f82.png",
      "/runtime.4197ba571343462bd99b.js",
      "/"
    ],
    "additional": [
      "/npm.material-ui.030c26b72836fd1bf24d.chunk.js",
      "/npm.dom-helpers.57808dae4e5b5d176cf9.chunk.js",
      "/npm.react-transition-group.f3bf07b1ac7f359070ce.chunk.js",
      "/3.5ce6a71fa986dc8eeece.chunk.js",
      "/4.8256f7e8e8d2039fdeb8.chunk.js",
      "/5.02cb633b6b4fd0ece69b.chunk.js",
      "/npm.css-loader.43d06fe7d2e73d5a01f7.chunk.js",
      "/npm.intl.8da3564e062e647a9e12.chunk.js",
      "/8.b299e42fe65dbcbde9e7.chunk.js",
      "/9.16931d07a2d8d4999712.chunk.js",
      "/main.29c06cb07ac9feef29a4.chunk.js",
      "/npm.axios.a19c5d7d2d686331e346.chunk.js",
      "/npm.babel.fe3f6581e514dca7a533.chunk.js",
      "/npm.connected-react-router.ccf5c49e5785f5a02b8a.chunk.js",
      "/npm.css-vendor.14fc7c85b3de315aa965.chunk.js",
      "/npm.enquire.js.4a330a7d3fca36f2f068.chunk.js",
      "/npm.lodash.50bd108e528d0d0545c9.chunk.js",
      "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
      "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
      "/npm.react-slick.36e50381840d2daae26a.chunk.js",
      "/npm.react-swipeable-views.196196bb169f5b1750b8.chunk.js",
      "/npm.slick-carousel.1f556f21044992c15f81.chunk.js",
      "/23.a5039d9989309fa2c9e2.chunk.js",
      "/24.6eefe28b798096aa8368.chunk.js",
      "/25.e244101c284a925b996d.chunk.js",
      "/26.470695772ca3de81c8ad.chunk.js",
      "/27.ae6216d45dfb00771cce.chunk.js",
      "/28.f39690243ee9df993351.chunk.js",
      "/29.925cc0c46315a4fbd5d2.chunk.js",
      "/30.50a2876b0b59a3c32339.chunk.js",
      "/31.bc31f4a08c4c158a73da.chunk.js",
      "/32.c3d238f1d65fce28ea9a.chunk.js",
      "/33.5b9b594dff3e8b3d7301.chunk.js",
      "/34.1faf4605360afd754ba2.chunk.js",
      "/35.4adf45d27bd6ed84ec3f.chunk.js",
      "/36.a3e18633b0bc6b816a12.chunk.js",
      "/37.e60170d03302e4cb482d.chunk.js",
      "/38.9f4761fd7c0a4a596639.chunk.js",
      "/39.7e6d84c2104fc86bf3d1.chunk.js",
      "/40.058302f75f3a80173d25.chunk.js",
      "/41.71ed240b30daf9355112.chunk.js",
      "/42.9144a998fa4c0584aa1c.chunk.js",
      "/43.4c8a75a5dbf8cb256542.chunk.js",
      "/44.c5a83bd8dcf2eaa81564.chunk.js",
      "/45.62580e5e7097a87c6e4f.chunk.js",
      "/46.0b011e2fdcbb2935be15.chunk.js",
      "/47.01b54d13519623b360c6.chunk.js",
      "/48.1add800469a752fde351.chunk.js",
      "/49.694e59f6d6bd094de9bb.chunk.js",
      "/50.11bcd7dd2ca62b86de78.chunk.js",
      "/51.0714da028778c84e64be.chunk.js",
      "/52.3ac9715fe152de8d8b47.chunk.js",
      "/53.b24e4bbdf8b05cdfce6f.chunk.js",
      "/54.42f00cb88f6de8f14b8c.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "efc9492a290a2fb3720b3c5bb5a469775e693bbb": "/354b3e8b3d2379621200e26eb4b1511d.svg",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "4a39d6bc4a2782ddd335cd07ed5e79030b10257c": "/92c9db83163207f1b8239ea93c890951.png",
    "b677a55607d7fc1d07c0a79d92c81bc19ff68496": "/45dae1f852dab39e3c142ffe41f12eea.png",
    "24ed9a27bda4d34918896cc632cdfec0f35bb44a": "/cb01bfd5df2c0bb8b3ee06a8e2bb256c.jpg",
    "5046dad658e24c72fa333e468df33b4af97bf875": "/c6bbb1c9229f10e2616370ff295f2f82.png",
    "e607857fef3cee608b4c99b026db0e7b013a33e5": "/npm.material-ui.030c26b72836fd1bf24d.chunk.js",
    "504767c33ca2a6efa8a8ef0605b9f3e782ba829e": "/npm.dom-helpers.57808dae4e5b5d176cf9.chunk.js",
    "dfaba795103c69c9c5b526844af53c3d7acde780": "/npm.react-transition-group.f3bf07b1ac7f359070ce.chunk.js",
    "4078a0c06c829be2088bd45b1c587ab6db7012c7": "/3.5ce6a71fa986dc8eeece.chunk.js",
    "4c55e32737223456ef068396ee9f2a30208a5aa5": "/4.8256f7e8e8d2039fdeb8.chunk.js",
    "1ce11a43e17ec7173549d173016037730537b78e": "/5.02cb633b6b4fd0ece69b.chunk.js",
    "b5d85ee36a7cbcdb7a9aa05f43296ed4d68462e4": "/npm.css-loader.43d06fe7d2e73d5a01f7.chunk.js",
    "473c59d62481ddcfd9a292e538e2303b53744cf7": "/npm.intl.8da3564e062e647a9e12.chunk.js",
    "e7606fdd10ada4fd1040edb33a28b60f67f06cbf": "/8.b299e42fe65dbcbde9e7.chunk.js",
    "4f902ff2771833c969c7b367b859e15bc24028f6": "/9.16931d07a2d8d4999712.chunk.js",
    "ffbce62c732f7aadcac112050e65b27712de74a6": "/main.29c06cb07ac9feef29a4.chunk.js",
    "3647a76e33a1e6105ac9d9c01d9d0f1825fd249a": "/npm.axios.a19c5d7d2d686331e346.chunk.js",
    "40ec0d6e21d8c9bcc436b1c7f38419b269977c40": "/npm.babel.fe3f6581e514dca7a533.chunk.js",
    "f73db0534017c675364b4e516c114c731bd8b88c": "/npm.connected-react-router.ccf5c49e5785f5a02b8a.chunk.js",
    "5af02a3a7b303877508a80fa597cd4db5e558aea": "/npm.css-vendor.14fc7c85b3de315aa965.chunk.js",
    "a5165404d8a730228cb823849c376a592a6355c8": "/npm.enquire.js.4a330a7d3fca36f2f068.chunk.js",
    "171809c3780e2112943c79fe1f412099a336fd27": "/npm.lodash.50bd108e528d0d0545c9.chunk.js",
    "6aa2bce4b04b5c348195ad5f80d3b482bc441b87": "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
    "2d3d4842d3f023f40286bf66ea301ee02bf85483": "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
    "becd48b8fb5627b3f33487b99b2398c958e9e272": "/npm.react-slick.36e50381840d2daae26a.chunk.js",
    "94779b36e5a599fae007cb4ba603b1bfca59fc52": "/npm.react-swipeable-views.196196bb169f5b1750b8.chunk.js",
    "5fd9e1123c4008e9b84cc74bd65696892e75fcc1": "/npm.slick-carousel.1f556f21044992c15f81.chunk.js",
    "b5a02b287831a10184f6de4de09a671e3be96c52": "/runtime.4197ba571343462bd99b.js",
    "a443866e28ebe92145592ce26172f81079def11f": "/23.a5039d9989309fa2c9e2.chunk.js",
    "612017fb6d3f559d2a0d3d432b75a189b7b795f9": "/24.6eefe28b798096aa8368.chunk.js",
    "5f02164ef0a0f1a0e59d0f143a464552eb203fed": "/25.e244101c284a925b996d.chunk.js",
    "be9b707cd41dd9a999ba63cbe3dc37f08cd04381": "/26.470695772ca3de81c8ad.chunk.js",
    "905a51d9bf28e054e797419534ef3d5c6324b753": "/27.ae6216d45dfb00771cce.chunk.js",
    "2d11c089aab25e943ac32b5f0e3303e479861543": "/28.f39690243ee9df993351.chunk.js",
    "02211dfe046e6afe99fa030dddd70aa1c02c1c6b": "/29.925cc0c46315a4fbd5d2.chunk.js",
    "19f6ea48ab3201328268c10068555e91d208e131": "/30.50a2876b0b59a3c32339.chunk.js",
    "35c803e61cb5f9f94f23bc7bfdeb9be2bbfcc134": "/31.bc31f4a08c4c158a73da.chunk.js",
    "2d508684e015f6a049c8af3e1d16db0d1d5a4f00": "/32.c3d238f1d65fce28ea9a.chunk.js",
    "dc57062199db0dc263d8e4a5b768b767e3a9005c": "/33.5b9b594dff3e8b3d7301.chunk.js",
    "6de7ac50a3b504f56b0aa2f063a933ea9ec83a6b": "/34.1faf4605360afd754ba2.chunk.js",
    "b170de8e218439dbfdeca42edf3f11c990eed41e": "/35.4adf45d27bd6ed84ec3f.chunk.js",
    "3c6521f24bb5058e745e986ba8ac824786e4830d": "/36.a3e18633b0bc6b816a12.chunk.js",
    "c352312f16549e61e43d4fac5bca0b29142c3b1b": "/37.e60170d03302e4cb482d.chunk.js",
    "da246eff1841ed992a221fadb3d5ee7454510d33": "/38.9f4761fd7c0a4a596639.chunk.js",
    "8d5c6914cdfb65340da458a21cc49d63fa3fc5e4": "/39.7e6d84c2104fc86bf3d1.chunk.js",
    "1603e6813236b347049d59c8abe09a53cba6388c": "/40.058302f75f3a80173d25.chunk.js",
    "66a84321f30810d8f66ca1245a6c1dc4933cbbd9": "/41.71ed240b30daf9355112.chunk.js",
    "bc6b8dfc983d17a6dfc05d0e8f616013808ffa7e": "/42.9144a998fa4c0584aa1c.chunk.js",
    "0714aa88394d33a0f7aeef91ef55fcac70b8b833": "/43.4c8a75a5dbf8cb256542.chunk.js",
    "ca8a1ab4d94251e3e4fdabf61f9996f6371e693a": "/44.c5a83bd8dcf2eaa81564.chunk.js",
    "ad2afd2b3140eeae91bf6f327950849f01d7e77c": "/45.62580e5e7097a87c6e4f.chunk.js",
    "48d200830336ff595620c541d8fce99ce3c612bc": "/46.0b011e2fdcbb2935be15.chunk.js",
    "745e4de87bb1eed32ee387b6d7e12737f076e879": "/47.01b54d13519623b360c6.chunk.js",
    "3d53aad55ac2f3fbe77790045ae9d5c432c71d7a": "/48.1add800469a752fde351.chunk.js",
    "99f373822f00d0456629101b85f31b19c0eedcf3": "/49.694e59f6d6bd094de9bb.chunk.js",
    "495898de7929e4b25bf837f04ecd7de8052f3725": "/50.11bcd7dd2ca62b86de78.chunk.js",
    "2b0da8f5768682f580eacd8903a7508fbae39d25": "/51.0714da028778c84e64be.chunk.js",
    "e7ac6e0692c5ee19930bae9a0af85bc288e2c845": "/52.3ac9715fe152de8d8b47.chunk.js",
    "5f193206df95db50e5c7eb2ea357867e36efa8be": "/53.b24e4bbdf8b05cdfce6f.chunk.js",
    "2d54a626a3487aa651b6ee2aaba56e47c06bd19e": "/54.42f00cb88f6de8f14b8c.chunk.js",
    "3ac2efdbc7fd3c73aa7bc77ba2388a7ee6a1e850": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "9/27/2020, 12:36:45 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });